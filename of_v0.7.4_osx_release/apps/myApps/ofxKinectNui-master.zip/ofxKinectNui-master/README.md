# Microsoft Kinect SDK 1.0 addon for openFrameworks

## License
built by sadmb  
facebook: sadmb  
twitter: @sadmb  
mail: sadam@sadmb.com

MIT license  
http://ja.wikipedia.org/wiki/MIT_License

## Disclaimer
Users must take full responsibility while using this software.  
We will not be liable for any loss or damage caused by this program.

## Requirement
1: You must install Visual C++ 2010, openFrameworks and Kinect SDK 1.0 before using this sample.  
2: Place this to openframeworks addons folder.